export const thousandComma = num => {
	return num.toLocaleString();
};
