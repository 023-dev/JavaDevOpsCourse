// color root 전역 변수

export const colors = {
	black: '#000',
	white: '#fff',
	input: '#e5e5e5',
};
