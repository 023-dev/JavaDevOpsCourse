import React from 'react';
import { Container } from './styles';

const OpenForm = ({ children }) => {
	return <Container>{children}</Container>;
};

export default OpenForm;
