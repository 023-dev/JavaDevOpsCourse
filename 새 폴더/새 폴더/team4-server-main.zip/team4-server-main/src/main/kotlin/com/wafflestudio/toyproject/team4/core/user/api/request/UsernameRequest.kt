package com.wafflestudio.toyproject.team4.core.user.api.request

data class UsernameRequest(
    val username: String
)
