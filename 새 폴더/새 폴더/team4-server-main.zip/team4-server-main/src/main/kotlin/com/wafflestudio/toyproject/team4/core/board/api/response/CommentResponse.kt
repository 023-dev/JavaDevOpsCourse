package com.wafflestudio.toyproject.team4.core.board.api.response

import com.wafflestudio.toyproject.team4.core.board.domain.Comment

data class CommentResponse(
    val comment: Comment
)
