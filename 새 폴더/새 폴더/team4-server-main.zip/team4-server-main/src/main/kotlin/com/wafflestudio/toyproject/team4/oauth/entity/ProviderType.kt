package com.wafflestudio.toyproject.team4.oauth.entity

enum class ProviderType {
    KAKAO, APPLE
}
