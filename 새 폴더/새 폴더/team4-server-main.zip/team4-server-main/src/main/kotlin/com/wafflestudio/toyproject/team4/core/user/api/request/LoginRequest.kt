package com.wafflestudio.toyproject.team4.core.user.api.request

data class LoginRequest(
    val username: String,
    val password: String
)
