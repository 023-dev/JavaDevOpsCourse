package com.wafflestudio.toyproject.team4.core.board.api.request

data class PutCommentRequest(
    val content: String,
)
