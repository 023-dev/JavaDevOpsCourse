package com.wafflestudio.toyproject.team4.core.user.api.request

data class PasswordRequest(
    val currentPassword: String
)
