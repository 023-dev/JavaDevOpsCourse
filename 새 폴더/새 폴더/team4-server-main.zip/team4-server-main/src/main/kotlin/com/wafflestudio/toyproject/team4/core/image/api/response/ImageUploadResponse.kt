package com.wafflestudio.toyproject.team4.core.image.api.response

data class ImageUploadResponse(
    val secureImages: List<String>
)
