package com.wafflestudio.toyproject.team4.core.purchase.api.request

data class PatchShoppingCartRequest(
    val id: Long,
    val quantity: Long
)
