package com.wafflestudio.toyproject.team4.core.user.api.request

data class RecentlyViewedRequest(
    val itemId: Long
)
