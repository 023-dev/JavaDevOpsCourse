package com.wafflestudio.toyproject.team4.core.user.api.response

data class AuthToken(
    val accessToken: String,
)
